create view pg_shmem_allocations(name, "off", size, allocated_size) as
SELECT name,
        off,
        size,
        allocated_size
        FROM pg_get_shmem_allocations() pg_get_shmem_allocations(name, off, size, allocated_size);

alter table pg_shmem_allocations
    owner to postgreuser;

grant select on pg_shmem_allocations to pg_read_all_stats;

